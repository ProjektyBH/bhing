var height = document.getElementById("getHeight").offsetHeight;
document.getElementById("height").innerHTML = height + "px";
